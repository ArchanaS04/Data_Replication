package com.example.partition.partitionexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartitionexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
